package com.nt.dto;

import java.io.Serializable;

public class EmpDTO implements Serializable {
	private int no,salary;
	private String name,job;
	
	public EmpDTO() {
		System.out.println("EmpDTO:0-param Constructor");
	}
		
	public EmpDTO(int no, int salary, String name, String job) {
		this.no = no;
		this.salary = salary;
		this.name = name;
		this.job = job;
	}


	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}
	
	
}
