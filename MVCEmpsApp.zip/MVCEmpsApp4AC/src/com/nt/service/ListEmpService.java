package com.nt.service;

import java.util.ArrayList;
import java.util.List;

import com.nt.bo.EmpBo;
import com.nt.dao.ListEmpDAO;
import com.nt.dto.EmpDTO;

public class ListEmpService {
	private ListEmpDAO dao;

	public void setDao(ListEmpDAO dao) {
		this.dao = dao;
	}
	public List<EmpDTO> getAllEmps(){
		//use DAO class
		List<EmpBo> listEmpBo=dao.retrieveEmps();
		//copy list of BO obj to list of DTO obj
		List<EmpDTO> listEmpDTO=new ArrayList<EmpDTO>();
		for(EmpBo bo:listEmpBo){
			EmpDTO empdto=new EmpDTO(bo.getNo(),bo.getSalary(),bo.getName(),bo.getJob());
			listEmpDTO.add(empdto);
		}
		return listEmpDTO;
	}
}
