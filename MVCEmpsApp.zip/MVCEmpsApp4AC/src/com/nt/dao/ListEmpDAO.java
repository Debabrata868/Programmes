package com.nt.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.nt.bo.EmpBo;


public class ListEmpDAO {

	private static final String GET_ALL_EMP_DETAILS="SELECT EMPNO,ENAME,JOB,SAL FROM EMP";
	
	private JdbcTemplate jt;

	public void setJt(JdbcTemplate jt) {
		this.jt = jt;
	}
	public List<EmpBo> retrieveEmps(){
		List<EmpBo> listEmpBo=(List<EmpBo>)jt.query(GET_ALL_EMP_DETAILS,new EmpRowMapper());
		return listEmpBo;
	}
	
	private class EmpRowMapper implements RowMapper<EmpBo>{
				
		@Override
		public EmpBo mapRow(ResultSet rs, int pos) throws SQLException {
			//place resultset obj record into BO class obj
			EmpBo empbo=new EmpBo();
			empbo.setNo(rs.getInt("empno"));
			empbo.setName(rs.getString("ename"));
			empbo.setJob(rs.getString("job"));
			empbo.setSalary(rs.getInt("sal"));
					
			return empbo;
		}
	}
}
